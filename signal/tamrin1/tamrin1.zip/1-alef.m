n1=1:9;
n2=n1+2;
n3=union(n1,n2);
x1=zeros(size(n3));
x=[4 3 2 1 0 1 2 3 4];
x1(n1)=x1(n1)+x.*2;
x1(n2)=x1(n2)+x.*4;
stem(n3,x1);