n=-10:10;
x1=max(n,0);
x2=max(-n,0);
x=5-x2-x1;
stem(n,x);