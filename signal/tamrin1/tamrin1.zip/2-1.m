n = -10:10;
n0=0;
delta=(n==n0);
stem(n,delta);