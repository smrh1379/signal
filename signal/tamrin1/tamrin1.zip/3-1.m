n=-5:5;
n1=-27:27;
x=repmat(n,1,5);
stem(n1,x);